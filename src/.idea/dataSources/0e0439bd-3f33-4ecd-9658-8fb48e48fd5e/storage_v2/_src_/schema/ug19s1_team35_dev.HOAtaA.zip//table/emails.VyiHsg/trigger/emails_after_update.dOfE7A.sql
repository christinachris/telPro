create definer = ug19s1_team35@`%` trigger emails_AFTER_UPDATE
  after UPDATE
  on emails
  for each row
BEGIN
    if new.is_primary=1
    then
      update clients set email=new.email_address where id=new.client_id;




    end if;
  END;

