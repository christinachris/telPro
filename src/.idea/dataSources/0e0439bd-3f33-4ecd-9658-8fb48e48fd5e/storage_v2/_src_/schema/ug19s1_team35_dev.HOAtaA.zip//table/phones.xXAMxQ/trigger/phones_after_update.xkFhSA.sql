create definer = ug19s1_team35@`%` trigger phones_AFTER_UPDATE
  after UPDATE
  on phones
  for each row
BEGIN
    if new.is_primary=1
    then
      update clients set phone_no=new.phone_no where id=new.client_id;




    end if;
  END;

