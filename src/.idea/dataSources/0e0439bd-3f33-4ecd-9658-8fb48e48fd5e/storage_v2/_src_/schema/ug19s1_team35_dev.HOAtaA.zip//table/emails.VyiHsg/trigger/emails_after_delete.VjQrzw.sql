create definer = ug19s1_team35@`%` trigger emails_AFTER_DELETE
  after DELETE
  on emails
  for each row
BEGIN
    if old.is_primary=1
    then
      update clients set email=null where id=old.client_id;



    end if;
  END;

