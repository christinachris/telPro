create definer = ug19s1_team35@`%` trigger phones_AFTER_DELETE
  after DELETE
  on phones
  for each row
BEGIN
    if old.is_primary=1
    then
      update clients set phone_no=null where id=old.client_id;



    end if;
  END;

